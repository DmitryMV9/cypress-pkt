
describe('Тестирование главной гугла', function () {
   it('Проверка, что при поиске теслы в выдаче есть тесла', function () {
        cy.visit('https:/...');
        cy.get("input[type='text'").type('text').type('{enter}');
        //cy.contains('bratishkinoff');
        cy.end();
    })
})
