
describe('Тестирование главной гугла', function () {
   it('Проверка, что при поиске теслы в выдаче есть тесла', function () {
        cy.visit('https://google.com');
        cy.get("input[type='text']").type('iphone 15promax').type('{enter}');
        cy.contains('https://support.apple.com/ja-jp/111828');
    })
})